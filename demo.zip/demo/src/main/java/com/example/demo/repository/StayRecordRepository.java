package com.example.demo.repository;
import com.example.demo.entity.StayRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StayRecordRepository extends JpaRepository<StayRecord, Long> {
}
