package com.example.demo.tool;

import com.example.demo.service.BookingService;
import dev.langchain4j.agent.tool.Tool;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Component
public class BookingTools {

    @Autowired
    private BookingService bookingService;

    // 注意：工具方法需要从会话中获取 userId，这里简化，通过静态变量或 ThreadLocal 传递，实际应使用 Session
    private static final ThreadLocal<String> currentUserId = new ThreadLocal<>();

    public static void setCurrentUserId(String userId) {
        currentUserId.set(userId);
    }

    public static void clear() {
        currentUserId.remove();
    }

    @Tool("预订酒店房间。需要提供房型名称（如大床房、双床房、套房）、入住日期（格式 yyyy-MM-dd）、离店日期（格式 yyyy-MM-dd）、房间数量（整数）")
    public String bookRoom(String roomTypeName, String checkInDateStr, String checkOutDateStr, int roomCount) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate checkIn = LocalDate.parse(checkInDateStr, formatter);
            LocalDate checkOut = LocalDate.parse(checkOutDateStr, formatter);
            return bookingService.bookRoom(currentUserId.get(), roomTypeName, checkIn, checkOut, roomCount);
        } catch (DateTimeParseException e) {
            return "日期格式错误，请提供 yyyy-MM-dd 格式的日期，例如 2025-05-01。";
        }
    }

    @Tool("查询当前用户的预订信息")
    public String queryReservation() {
        return bookingService.queryReservation(currentUserId.get());
    }
}