package com.example.demo.service.impl;

import com.example.demo.service.Assistant;
import com.example.demo.service.ChatService;
import com.example.demo.tool.BookingTools;
import dev.langchain4j.community.model.dashscope.QwenChatModel;
// 关键：使用 ChatLanguageModel 接口，而不是 ChatModel
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.service.AiServices;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ChatServiceImpl implements ChatService {

    @Value("${langchain4j.community.dashscope.chat-model.api-key}")
    private String apiKey;

    @Value("${langchain4j.community.dashscope.chat-model.model-name}")
    private String modelName;

    private Assistant assistant;

    @PostConstruct
    public void init() {
        // 使用 ChatLanguageModel 类型接收 QwenChatModel 实例
        ChatLanguageModel model = QwenChatModel.builder()
                .apiKey(apiKey)
                .modelName(modelName)
                .build();

        assistant = AiServices.builder(Assistant.class)
                .chatLanguageModel(model)  // 现在参数类型匹配了
                .tools(new BookingTools())
                .build();
    }

    @Override
    public String chat(String userId, String userMessage) {
        BookingTools.setCurrentUserId(userId);
        try {
            return assistant.chat(userMessage);
        } finally {
            BookingTools.clear();
        }
    }
}